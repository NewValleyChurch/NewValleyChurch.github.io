# NewValleyChurch.github.io

The mess of files you see here is an adaptation of the Jekyll Documentation Theme design by [this guy](http://idratherbewriting.com/aboutme/).

Big thanks to Tom Johnson for putting this together.
